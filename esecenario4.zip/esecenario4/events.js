var baby= document.querySelector (".baby")
baby.addEventListener("click", CambioImg)
var young= document.querySelector(".young")

function CambioImg(){    
    /* young.classList.add("oculto") */
    young.classList.remove('oculto')
}
