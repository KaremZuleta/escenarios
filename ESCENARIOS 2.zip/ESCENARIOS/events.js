var Igor= document.querySelector (".Igor")
Igor.addEventListener("click", CambioImg)
var imagen= document.querySelector("img")
var emma= document.querySelector(".emma")
var hada = document.querySelector('.hada')

function CambioImg(){    
    emma.classList.add("oculto")
    hada.classList.remove('oculto')
}



